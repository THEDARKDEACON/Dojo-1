from __future__ import generator_stop
from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, concat, escape, identity, internalcode, markup_join, missing, str_join
name = 'definition_functions.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_define_enum = l_0_define_struct = missing
    try:
        t_1 = environment.filters['default_value']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'default_value' found.")
    try:
        t_2 = environment.filters['is_scoped']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_scoped' found.")
    try:
        t_3 = environment.filters['name']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'name' found.")
    pass
    def macro(l_1_enum):
        t_4 = []
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        t_4.extend((
            'enum',
            str((' class' if t_2(l_1_enum) else cond_expr_undefined("the inline if-expression on line 12 in 'definition_functions.tmpl' evaluated to false and no else section was defined."))),
            ' ',
            str(environment.getattr(l_1_enum, 'mojom_name')),
            ' {',
        ))
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            _loop_vars = {}
            pass
            t_4.extend((
                '\n\t',
                str(environment.getattr(l_2_field, 'mojom_name')),
                ' = ',
                str(environment.getattr(l_2_field, 'numeric_value')),
                ',',
            ))
        l_2_field = missing
        t_4.append(
            '\n};',
        )
        return concat(t_4)
    context.exported_vars.add('define_enum')
    context.vars['define_enum'] = l_0_define_enum = Macro(environment, macro, 'define_enum', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_struct):
        t_5 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        t_5.extend((
            'struct ',
            str(environment.getattr(l_1_struct, 'mojom_name')),
            '\n{\npublic:\n#ifndef __DOXYGEN__\n\t',
            str(environment.getattr(l_1_struct, 'mojom_name')),
            '() = default;\n\n\ttemplate<',
        ))
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_5.extend((
                '\n\t\ttypename T',
                str(environment.getattr(l_2_loop, 'index')),
                ' = ',
                str(t_3(l_2_field)),
                ',',
            ))
        l_2_loop = l_2_field = missing
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_5.extend((
                '\n\t\tstd::enable_if_t<std::is_convertible_v<T',
                str(environment.getattr(l_2_loop, 'index')),
                '&&, ',
                str(t_3(l_2_field)),
                '>> * = nullptr',
                str((',' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 36 in 'definition_functions.tmpl' evaluated to false and no else section was defined."))),
            ))
        l_2_loop = l_2_field = missing
        t_5.extend((
            '\n\t>\n\t',
            str(environment.getattr(l_1_struct, 'mojom_name')),
            '(',
        ))
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_5.extend((
                'T',
                str(environment.getattr(l_2_loop, 'index')),
                ' &&_',
                str(environment.getattr(l_2_field, 'mojom_name')),
                str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 41 in 'definition_functions.tmpl' evaluated to false and no else section was defined."))),
            ))
        l_2_loop = l_2_field = missing
        t_5.append(
            ')',
        )
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_5.extend((
                '\n\t\t',
                str((': ' if environment.getattr(l_2_loop, 'first') else ', ')),
                str(environment.getattr(l_2_field, 'mojom_name')),
                '(std::forward<T',
                str(environment.getattr(l_2_loop, 'index')),
                '>(_',
                str(environment.getattr(l_2_field, 'mojom_name')),
                '))',
            ))
        l_2_loop = l_2_field = missing
        t_5.append(
            '\n\t{\n\t}\n#endif\n\n',
        )
        for l_2_field in environment.getattr(l_1_struct, 'fields'):
            _loop_vars = {}
            pass
            t_5.extend((
                '\n\t',
                str(t_3(l_2_field)),
                ' ',
                str(environment.getattr(l_2_field, 'mojom_name')),
            ))
            if t_1(l_2_field):
                pass
                t_5.extend((
                    '{ ',
                    str(t_1(l_2_field)),
                    ' }',
                ))
            t_5.append(
                ';',
            )
        l_2_field = missing
        t_5.append(
            '\n};',
        )
        return concat(t_5)
    context.exported_vars.add('define_struct')
    context.vars['define_struct'] = l_0_define_struct = Macro(environment, macro, 'define_struct', ('struct',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '11=30&12=37&13=42&14=47&24=59&25=66&29=68&32=72&33=77&35=84&36=89&39=98&40=102&41=107&44=117&45=122&51=134&52=139'